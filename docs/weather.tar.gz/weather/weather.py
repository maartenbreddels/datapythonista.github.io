# -*- coding: utf-8 -*-
"""
Created on Wed Apr  6 10:48:53 2016

@author: sibo
"""


import bottle
import forecastio
import datetime


cities = {
        'bakau'     : (13.478, -16.682), 
        'banjul'    : (13.453, -16.578),
        'brikama'   : (13.271, -16.649),
        'farafenni' : (13.567, -15.6),
        'gunjur'    : (13.202, -16.734),
        'soma'      : (13.433, -15.533),
        'nyc'       : (40.714, -74.006)
        }

@bottle.route('/forecast/<city>')
def index(city):
    if (city in cities):
        api_key = "f1a35496d543f2b794404f777f443ed7"
        dat = datetime.datetime.now() + datetime.timedelta(days=1)
        forecast = forecastio.load_forecast(api_key, cities[city][0], cities[city][1], time=dat, units="si")
        tomorrow = forecast.currently()
        temp = tomorrow.d['temperature']


        return str(temp)
        # return city+" has a cordinate of: "+str(cities[city][0])+"/"+ str(cities[city][1])+ ": "+ str(temp)
    else:
        return "Oops! "+ city +" does not exist in out database..."        
        

bottle.run(host='localhost', port=8181)