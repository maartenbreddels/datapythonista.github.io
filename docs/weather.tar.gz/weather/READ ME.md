#Weather Forecast Service#

##Installation##
* Install the bottle framework with: pip install bottle
* Install the HTTP client library for web services with: pip install httplib2
* Install the python wrapper for the forecast.io API with: pip install python-forecastio

##How to Test##
* Run the weather.py web service first
* Then run the testWeather.py script

##How it works##
* The script sends a request to the web service with the name of the city to forecast using the request function of the httplib2 object.
* The web services listens on a route using the bottle framework and grabs the last segment, check if it exist in the cities dictionary, else returns an error message.
* If the city exist, it passes its tuple values as the longitude and latitude with the api key and date to the load_forecast() function of the forecastio object.
*This returns a json object that is accessed to retrieve the temperature

##Time Spent##
* I spent 2 hours 18 minutes. Most of that time was spent on fixing the httplib2 problem that I encountered ("ImportError: No module named httplib2") because I installed it using apt-get and python was not seeing it. Had to use pip later


