# -*- coding: utf-8 -*-
"""
Created on Wed Apr  6 12:24:10 2016

@author: sibo
"""

import httplib2
h = httplib2.Http(".cache")

city = "gunjurs"
url = "http://localhost:8181/forecast/"+city
(headers, content) = h.request(url, "GET")
content = str(content, encoding='UTF-8')

if(len(content) > 5):
    print(content)
else:
    print('# python weather.py --city='+city+
        '\n Weather forecast for tomorrow in '+city+
        '\n Temperature: '+ content+ u"\u2103")
